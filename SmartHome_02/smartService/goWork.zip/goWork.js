var lamp = require("./lamp.js");
var sa = require("./security.js");
var ac = require("./conditioner.js");
var tv = require("./Tv.js");
var audio = require("./Audio.js");

exports.handler = (event, context, callback) => {
        var gowork = event.gowork;
        
        if(gowork){
                var result=Go_work2()
        }
        
        callback(null,result);
}

function Go_work2() {
        ac.ac_off();
        tv.tv_off();
        audio.audio_off();
        lamp.lamp_off();
        sa.sa_on();
        
        var object_list;
        object_list = {
                'lamp':lamp.lamp_show(), 
                'ac':ac.ac_show(),
                'tv':tv.tv_show(),
                'audio':audio.audio_show()}
        
        return object_list;
}