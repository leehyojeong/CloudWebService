var lamp = require("./lamp.js");
var sa = require("./security.js");
var ac = require("./conditioner.js");
var tv = require("./Tv.js");
var audio = require("./Audio.js");

exports.handler = (event, context, callback) => {
        var issleep = event.issleep;
        
        if(issleep){
                var result=Go_Sleep2()
        }
        
        callback(null,result);
}

function Go_Sleep2() {
        lamp.lamp_off();
        sa.sa_on();
        tv.tv_off();
        audio.audio_off();
        
        var object_list;
        object_list = {
                'lamp':lamp.lamp_show(), 
                'ac':ac.ac_show(),
                'tv':tv.tv_show(),
                'audio':audio.audio_show()}
        
        return object_list;
}

