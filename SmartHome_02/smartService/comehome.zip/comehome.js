var lamp = require("./lamp.js");
var sa = require("./security.js");
var ac = require("./conditioner.js");

exports.handler = (event, context, callback) => {
        if(event.ishome) var result = Come_Home();
        callback(null, result);
};

function Come_Home(){
        var result = {"conditioner":ac.ac_Turn_On(), "lamp":lamp.lamp_on(), "security alarm":sa.sa_Turn_Off()};
        return result;
}
