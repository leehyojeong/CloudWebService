var lamp = require("./lamp.js");
var sa = require("./security.js");
var ac = require("./conditioner.js");
var tv = require("./Tv.js");
var audio = require("./Audio.js");
function show2() {
        ac.ac_show();
        tv.tv_show();
        audio.audio_show();
        lamp.lamp_show();
        sa.sa_show();
}

function show() {
        var status = {
                "conditioner":ac.ac_show(),
                "lamp":lamp.lamp_show(),
                "security alarm":sa.sa_show(),
                "tv":tv.tv_show(),
                "audio":audio.audio_show()
        };
        return status;
}

module.exports={
        show:show,
        show2:show2
}
