var lamp = require("./lamp.js");
var sa = require("./security.js");
var ac = require("./conditioner.js");
var tv = require("./Tv.js");
var audio = require("./Audio.js");

function Come_Home2(){
        ac.ac_on();
        lamp.lamp_on();
        sa.sa_off();
}

function show() {
        var status = {
                "conditioner":ac.ac_show();
                "lamp":lamp.lamp_show();
                "security alarm":sa.sa_show();
        };
        return status;
}

module.exports = {
        comehome:Come_Home,
        comehome2:Come_Home2,
        show:show
}
