var lamp = require("./lamp.js");
var sa = require("./security.js");
var ac = require("./conditioner.js");
var tv = require("./Tv.js");
var audio = require("./Audio.js");

exports.handler = (event, context, callback) => {
        var iswakeup = event.iswakeup;
        
        if(iswakeup){
                var result=wake_Up2()
        }
        
        callback(null,result);
}

function wake_Up2() {
        tv.tv_on();
        lamp.lamp_on();
        sa.sa_off();
                
        var object_list;
        object_list = {
                'tv':tv.tv_show(), 
                'lamp':lamp.lamp_show(),
                'sa':sa.sa_show()}
        
        return object_list;
        
}