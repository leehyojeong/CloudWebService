var gosleep = require("./gosleep.js");
var gowork = require("./goWork.js");
var wakeup = require("./wakeup.js");
var showall = require("./showall.js");
var comehome = require("./comehome.js");

exports.handler = (event, context, callback) => {
   if(event.iswakeup) wakeup.wakeup2();
   if(event.iswork) gowork.gowork2();
   if(event.ishome) comehome.comehome2();
   if(event.issleep) gosleep.gosleep2();

   var result = {
      "gosleep":gosleep.show(),
      "wakeup":wakeup.show(),
      "goWork":gowork.show(),
      "comehome":comehome.show(),
      "showall":showall.show()
   };
   
   callback(null, result);

}